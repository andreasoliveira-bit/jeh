import { createFileRoute } from "@tanstack/react-router";
import {
  Accessibility,
  CloudSun,
  HeartHandshake,
  Landmark,
  Leaf,
  School,
  ShieldCheck,
  CalendarClock,
  Wrench,
  Zap,
  ChevronDown,
  Sun,
} from "lucide-react";
import type { ReactNode } from "react";

import heroImg from "@/assets/piscina-coberta.jpg.asset.json";
import alunosImg from "@/assets/alunos-nadando.jpg.asset.json";
import solarImg from "@/assets/aquecimento-solar.jpg.asset.json";
import hibridoImg from "@/assets/sistema-hibrido.jpg.asset.json";
import escolaImg from "@/assets/piscina-escola.jpg.asset.json";
import {
  acesso,
  beneficios,
  criterios,
  custos,
  energia,
  investimento,
  perguntas,
  projeto,
  responsabilidades,
} from "@/content/projeto";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Projeto IFA — Piscina aquecida o ano inteiro | 2º B noturno" },
      {
        name: "description",
        content:
          "Apresentação aos pais do Projeto IFA: benefícios, custos e sustentabilidade do aquecimento da piscina da escola, por Peterson, Augusto e Jessica.",
      },
      { property: "og:title", content: "Projeto IFA — Piscina aquecida o ano inteiro" },
      {
        property: "og:description",
        content:
          "Benefícios, viabilidade e sustentabilidade do aquecimento da piscina da escola. Turma 2º B noturno.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const nav = [
  { href: "#beneficios", label: "Benefícios" },
  { href: "#custos", label: "Custos" },
  { href: "#energia", label: "Energia" },
  { href: "#solucao", label: "Solução" },
  { href: "#perguntas", label: "Perguntas" },
];

const criterioIcons = [Zap, CloudSun, Wrench];
const acessoIcons = [Accessibility, ShieldCheck, CalendarClock];
const respIcons = [Landmark, School, HeartHandshake];

function Eyebrow({ children, onDark = false }: { children: ReactNode; onDark?: boolean }) {
  return (
    <p
      className={`mb-4 text-sm font-semibold uppercase tracking-[0.18em] ${onDark ? "text-aqua" : "text-primary"}`}
    >
      {children}
    </p>
  );
}

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <header className="absolute inset-x-0 top-0 z-20">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5 sm:px-8">
          <a href="#topo" className="font-display text-lg font-extrabold text-deep-foreground">
            {projeto.nome}
          </a>
          <nav className="hidden gap-7 text-sm font-medium text-deep-muted md:flex">
            {nav.map((n) => (
              <a key={n.href} href={n.href} className="transition-colors hover:text-aqua">
                {n.label}
              </a>
            ))}
          </nav>
          <span className="rounded-full border border-deep-foreground/25 px-3 py-1 text-xs font-semibold text-deep-foreground">
            {projeto.turma}
          </span>
        </div>
      </header>

      <main id="topo">
        {/* Abertura */}
        <section className="relative overflow-hidden bg-deep-gradient text-deep-foreground">
          <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 pb-20 pt-28 sm:px-8 lg:grid-cols-[1.05fr_1fr] lg:pb-28 lg:pt-36">
            <div className="animate-rise">
              <Eyebrow onDark>Apresentação aos pais</Eyebrow>
              <h1 className="text-[2.6rem] font-extrabold uppercase leading-[0.98] sm:text-6xl lg:text-7xl">
                {projeto.titulo[0]} <span className="text-aqua">{projeto.titulo[1]}</span>
              </h1>
              <p className="mt-6 max-w-md text-lg text-deep-muted">{projeto.subtitulo}</p>
              <dl className="mt-10 flex flex-wrap gap-x-10 gap-y-4 border-t border-deep-foreground/15 pt-6 text-sm">
                <div>
                  <dt className="text-deep-muted">Alunos responsáveis</dt>
                  <dd className="mt-1 text-base font-semibold">
                    {projeto.alunos.slice(0, -1).join(", ")} e {projeto.alunos.at(-1)}
                  </dd>
                </div>
                <div>
                  <dt className="text-deep-muted">Turma</dt>
                  <dd className="mt-1 text-base font-semibold">{projeto.turma}</dd>
                </div>
              </dl>
            </div>
            <div className="animate-rise [animation-delay:150ms]">
              <img
                src={heroImg.url}
                alt="Piscina coberta de escola com painéis solares e reservatório de água quente"
                width={1672}
                height={941}
                className="blob aspect-[4/3] w-full object-cover shadow-float"
              />
            </div>
          </div>
        </section>

        {/* Benefícios */}
        <section id="beneficios" className="scroll-mt-8 px-5 py-20 sm:px-8 lg:py-28">
          <div className="mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-2">
            <img
              src={alunosImg.url}
              alt="Estudantes nadando em uma piscina aquecida com o professor ao fundo"
              loading="lazy"
              width={1095}
              height={941}
              className="aspect-[5/4] w-full rounded-3xl object-cover shadow-float"
            />
            <div>
              <Eyebrow>Por que aquecer</Eyebrow>
              <h2 className="text-4xl font-extrabold leading-tight sm:text-5xl">
                Uma piscina ativa em <span className="text-primary">todas as estações</span>
              </h2>
              <ul className="mt-8 space-y-5">
                {beneficios.map((b, i) => (
                  <li key={b} className="flex gap-4 text-lg">
                    <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-accent font-display text-sm font-bold text-accent-foreground">
                      {i + 1}
                    </span>
                    {b}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* Investimento + critérios */}
        <section className="bg-water-gradient px-5 py-20 sm:px-8 lg:py-28">
          <div className="mx-auto max-w-6xl">
            <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr]">
              <div>
                <Eyebrow>Viabilidade</Eyebrow>
                <h2 className="text-4xl font-extrabold leading-tight sm:text-5xl">
                  Quando o investimento se justifica
                </h2>
              </div>
              <ul className="divide-y divide-border border-y border-border text-lg">
                {investimento.map((t) => (
                  <li key={t} className="py-5">
                    {t}
                  </li>
                ))}
              </ul>
            </div>

            <h3 className="mt-20 text-2xl font-bold sm:text-3xl">Critérios para escolher a tecnologia</h3>
            <div className="mt-8 grid gap-5 md:grid-cols-3">
              {criterios.map((c, i) => {
                const Icon = criterioIcons[i] ?? Zap;
                return (
                  <article key={c.titulo} className="rounded-3xl bg-card p-7 shadow-float">
                    <Icon className="h-9 w-9 text-primary" aria-hidden />
                    <h4 className="mt-5 font-display text-xl font-bold">{c.titulo}</h4>
                    <p className="mt-2 text-muted-foreground">{c.texto}</p>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        {/* Custos */}
        <section id="custos" className="scroll-mt-8 px-5 py-20 sm:px-8 lg:py-28">
          <div className="mx-auto max-w-6xl">
            <Eyebrow>Custos</Eyebrow>
            <h2 className="max-w-2xl text-4xl font-extrabold leading-tight sm:text-5xl">
              O custo vai além da instalação
            </h2>
            <ol className="mt-12 grid gap-8 md:grid-cols-3">
              {custos.map((c, i) => (
                <li key={c} className="border-t-4 border-primary pt-5">
                  <span className="font-display text-5xl font-extrabold text-primary">{i + 1}</span>
                  <p className="mt-3 text-lg">{c}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* Energia */}
        <section id="energia" className="scroll-mt-8 bg-deep-gradient px-5 py-20 text-deep-foreground sm:px-8 lg:py-28">
          <div className="mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-2">
            <div>
              <Eyebrow onDark>Meio ambiente</Eyebrow>
              <h2 className="text-4xl font-extrabold uppercase leading-none sm:text-6xl">
                A fonte de energia <span className="text-aqua">importa</span>
              </h2>
              <ul className="mt-8 space-y-5 text-lg text-deep-muted">
                {energia.map((e, i) => (
                  <li key={e} className="flex gap-4">
                    {i === 0 ? (
                      <Zap className="mt-1 h-6 w-6 shrink-0 text-sun" aria-hidden />
                    ) : i === 1 ? (
                      <Sun className="mt-1 h-6 w-6 shrink-0 text-sun" aria-hidden />
                    ) : (
                      <Leaf className="mt-1 h-6 w-6 shrink-0 text-aqua" aria-hidden />
                    )}
                    {e}
                  </li>
                ))}
              </ul>
            </div>
            <img
              src={solarImg.url}
              alt="Placas de aquecimento solar no telhado ao lado de uma piscina"
              loading="lazy"
              width={1672}
              height={941}
              className="aspect-[4/3] w-full rounded-3xl object-cover shadow-float"
            />
          </div>
        </section>

        {/* Acesso */}
        <section className="px-5 py-20 sm:px-8 lg:py-28">
          <div className="mx-auto max-w-6xl">
            <Eyebrow>Para todos</Eyebrow>
            <h2 className="max-w-2xl text-4xl font-extrabold leading-tight sm:text-5xl">
              Segurança e acesso democrático
            </h2>
            <div className="mt-12 grid gap-5 md:grid-cols-3">
              {acesso.map((a, i) => {
                const Icon = acessoIcons[i] ?? ShieldCheck;
                return (
                  <article key={a.titulo} className="rounded-3xl bg-secondary p-7">
                    <Icon className="h-9 w-9 text-primary" aria-hidden />
                    <h3 className="mt-5 text-xl font-bold">{a.titulo}</h3>
                    <p className="mt-2 text-secondary-foreground">{a.texto}</p>
                  </article>
                );
              })}
            </div>

            <h3 className="mt-20 text-2xl font-bold sm:text-3xl">Responsabilidade compartilhada</h3>
            <div className="mt-8 grid gap-x-10 gap-y-8 md:grid-cols-3">
              {responsabilidades.map((r, i) => {
                const Icon = respIcons[i] ?? School;
                return (
                  <div key={r.quem} className="flex gap-4">
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      <Icon className="h-6 w-6" aria-hidden />
                    </span>
                    <div>
                      <h4 className="font-display text-lg font-bold">{r.quem}</h4>
                      <p className="mt-1 text-muted-foreground">{r.texto}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Solução */}
        <section id="solucao" className="scroll-mt-8 px-5 pb-20 sm:px-8 lg:pb-28">
          <div className="relative mx-auto max-w-6xl overflow-hidden rounded-[2rem] shadow-float">
            <img
              src={hibridoImg.url}
              alt="Piscina com placas solares, reservatório e bomba de calor"
              loading="lazy"
              width={1672}
              height={941}
              className="h-72 w-full object-cover sm:h-96"
            />
            <div className="bg-deep-gradient p-8 text-deep-foreground sm:p-12">
              <Eyebrow onDark>Nossa conclusão</Eyebrow>
              <h2 className="text-4xl font-extrabold leading-tight sm:text-5xl">
                O equilíbrio está na <span className="text-aqua">solução híbrida</span>
              </h2>
              <p className="mt-4 font-display text-xl font-semibold">
                Solar térmico com apoio elétrico ou bomba de calor
              </p>
              <p className="mt-4 max-w-2xl text-lg text-deep-muted">
                Investimento inicial maior; baixo custo mensal, alta sustentabilidade e funcionamento
                constante mesmo em dias nublados.
              </p>
            </div>
          </div>
        </section>

        {/* Perguntas */}
        <section id="perguntas" className="scroll-mt-8 bg-water-gradient px-5 py-20 sm:px-8 lg:py-28">
          <div className="mx-auto max-w-3xl">
            <Eyebrow>Perguntas e respostas</Eyebrow>
            <h2 className="text-4xl font-extrabold leading-tight sm:text-5xl">O que o grupo investigou</h2>
            <div className="mt-10 space-y-3">
              {perguntas.map((p, i) => (
                <details key={p.pergunta} className="group rounded-2xl bg-card px-6 py-5 shadow-float" open={i === 0}>
                  <summary className="flex cursor-pointer list-none items-start gap-4 font-display text-lg font-bold [&::-webkit-details-marker]:hidden">
                    <span className="text-primary">{i + 1}.</span>
                    <span className="flex-1">{p.pergunta}</span>
                    <ChevronDown
                      className="mt-1 h-5 w-5 shrink-0 text-primary transition-transform group-open:rotate-180"
                      aria-hidden
                    />
                  </summary>
                  <p className="mt-4 pl-8 text-muted-foreground">{p.resposta}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* Fechamento */}
        <section className="relative overflow-hidden bg-deep text-deep-foreground">
          <img
            src={escolaImg.url}
            alt=""
            loading="lazy"
            width={1672}
            height={941}
            className="absolute inset-0 h-full w-full object-cover opacity-25"
          />
          <div className="relative mx-auto max-w-4xl px-5 py-24 text-center sm:px-8 lg:py-32">
            <h2 className="text-4xl font-extrabold leading-tight sm:text-6xl">
              Uma piscina aquecida pode servir a todos, <span className="text-aqua">o ano inteiro.</span>
            </h2>
            <p className="mx-auto mt-6 max-w-xl text-lg text-deep-muted">
              Planejamento, sustentabilidade e participação mantêm o projeto em funcionamento.
            </p>
          </div>
        </section>
      </main>

      <footer className="bg-deep px-5 py-8 text-center text-sm text-deep-muted sm:px-8">
        {projeto.nome} · {projeto.alunos.slice(0, -1).join(", ")} e {projeto.alunos.at(-1)} · {projeto.turma}
      </footer>
    </div>
  );
}
