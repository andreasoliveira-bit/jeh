// Todo o texto do site vem da apresentação e das perguntas e respostas do grupo.
export const projeto = {
  nome: "Projeto IFA",
  turma: "2º B noturno",
  alunos: ["Peterson", "Augusto", "Jessica"],
  titulo: ["Piscinas aquecidas,", "oportunidades o ano inteiro"],
  subtitulo: "Benefícios, viabilidade e sustentabilidade para a comunidade escolar",
};

export const beneficios = [
  "Amplia as aulas de Educação Física durante todo o ano.",
  "Incentiva a prática esportiva e melhora a saúde dos estudantes.",
  "Abre espaço para aulas de natação e projetos sociais para a comunidade local.",
];

export const investimento = [
  "O benefício coletivo precisa superar o custo financeiro a longo prazo.",
  "A alta utilização por alunos e moradores demonstra o valor do projeto.",
  "O uso consistente evita que a estrutura fique ociosa.",
];

export const criterios = [
  { titulo: "Eficiência energética", texto: "Quanto de energia o sistema gasta para manter a água aquecida." },
  { titulo: "Clima da região", texto: "Dias de sol e de chuva mudam o que cada tecnologia consegue entregar." },
  {
    titulo: "Manutenção, durabilidade e orçamento",
    texto: "Equipamentos duráveis, fáceis de manter e que caibam nos custos.",
  },
];

export const custos = [
  "A instalação é apenas o início do projeto.",
  "Despesas mensais altas com energia ou gás podem comprometer o funcionamento.",
  "Manutenções complexas exigem verba fixa para custeio contínuo.",
];

export const energia = [
  "Sistemas elétricos convencionais e a gás aumentam o consumo de recursos e podem gerar emissões de carbono.",
  "O aquecimento solar térmico aproveita uma fonte limpa e renovável.",
  "A solução solar reduz drasticamente a pegada ambiental.",
];

export const acesso = [
  {
    titulo: "Acessibilidade",
    texto: "Instalar rampas ou cadeiras de transferência para pessoas com deficiência.",
  },
  {
    titulo: "Segurança",
    texto: "Usar pisos antiderrapantes e capas térmicas para ajudar a evitar acidentes.",
  },
  {
    titulo: "Organização",
    texto: "Distribuir horários entre turmas e grupos da comunidade sem exclusão.",
  },
];

export const responsabilidades = [
  { quem: "Poder público", texto: "Financia a obra e garante verba de custeio." },
  { quem: "Gestão escolar", texto: "Organiza o cronograma, a segurança e a manutenção básica." },
  { quem: "Comunidade e estudantes", texto: "Ajudam a conservar o espaço." },
];

export const perguntas = [
  {
    pergunta: "Quais benefícios educacionais, esportivos e sociais o aquecimento da piscina pode proporcionar?",
    resposta:
      "Permite utilizar a piscina durante todo o ano, ampliando as aulas de Educação Física, incentivando a natação, melhorando a saúde dos estudantes e oferecendo atividades esportivas e de lazer à comunidade.",
  },
  {
    pergunta: "Como avaliar se o investimento é justificado para uma instituição pública?",
    resposta:
      "É necessário comparar os custos de instalação e manutenção com os benefícios oferecidos. O investimento se justifica quando atende muitos alunos e moradores, garantindo o bom aproveitamento da estrutura pública.",
  },
  {
    pergunta: "Quais critérios devem orientar a escolha entre diferentes tecnologias?",
    resposta:
      "Devem ser considerados a eficiência energética, o clima da região, os custos, a durabilidade dos equipamentos, a facilidade de manutenção e os impactos ambientais.",
  },
  {
    pergunta: "Como os custos de instalação, operação e manutenção afetam a viabilidade do projeto?",
    resposta:
      "Os custos influenciam diretamente a continuidade do projeto. Além da instalação, é necessário prever gastos com energia, manutenção e conservação para evitar que o sistema deixe de funcionar por falta de recursos.",
  },
  {
    pergunta: "Quais impactos ambientais estão associados às fontes de energia utilizadas?",
    resposta:
      "Sistemas elétricos e a gás podem gerar impactos ambientais e emissões de carbono. Já o aquecimento solar utiliza uma fonte renovável, reduzindo o consumo de energia convencional e os impactos ambientais.",
  },
  {
    pergunta: "Como garantir a segurança, a acessibilidade e a utilização democrática da piscina?",
    resposta:
      "É importante instalar pisos antiderrapantes, rampas, corrimãos e equipamentos de acessibilidade. Também devem existir regras de segurança e horários organizados para garantir o acesso de todos.",
  },
  {
    pergunta:
      "Que responsabilidades cabem à escola, ao poder público e à comunidade na implantação e manutenção do sistema?",
    resposta:
      "O poder público deve fornecer os recursos financeiros, a escola deve organizar e fiscalizar o funcionamento, e a comunidade deve colaborar com a conservação e o uso responsável da piscina.",
  },
  {
    pergunta:
      "Qual solução apresenta o melhor equilíbrio entre eficiência energética, custo, sustentabilidade e benefícios sociais?",
    resposta:
      "O sistema híbrido, que combina aquecimento solar com bomba de calor, é uma alternativa interessante. Ele aproveita a energia solar, reduz os gastos de funcionamento e mantém a água aquecida mesmo em períodos de pouca incidência solar.",
  },
];
